package main //必须

func main() {
	test()
}
