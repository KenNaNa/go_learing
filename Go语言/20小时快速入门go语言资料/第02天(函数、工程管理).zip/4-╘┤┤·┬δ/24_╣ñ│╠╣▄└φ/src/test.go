package main

import "fmt"

func test() {
	fmt.Println("this is a test func")
}
